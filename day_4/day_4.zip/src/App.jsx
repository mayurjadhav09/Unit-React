import logo from './logo.svg';
import './App.css';
import { Grocy } from './comp/Grocy';

function App() {
  return (
    <div className="App">
       <h1> Grocery List</h1>
      <Grocy/>
     
    </div>
  );
}

export default App;
