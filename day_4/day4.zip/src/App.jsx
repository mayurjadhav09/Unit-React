import logo from './logo.svg';
import './App.css';
import { Grocy } from './comp/Grocy';

function App() {
  return (
    <div className="App">
      <h1>Hello world</h1>
      <Grocy/>
     
    </div>
  );
}

export default App;
