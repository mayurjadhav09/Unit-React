export const GrocyList=({title,status,id,delGrocy})=>{
    return(
        <div className="List">
            {title}-{status ?"Done" : "Not Done"}
            <button onClick={()=>{
                delGrocy(id)
            }}>Delete</button>
        </div>
    )
}