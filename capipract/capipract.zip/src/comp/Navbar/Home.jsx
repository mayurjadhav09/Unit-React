


export const Home=()=>{

    return <div className="form">
        <h1>Welcome To Home Page</h1>
    </div>
}