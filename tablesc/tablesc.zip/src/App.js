// import logo from './logo.svg';
import './App.css';
import { Tablestyled } from './component/table';

function App() {
  return (
    <div className="App">
     <Tablestyled/>
    </div>
  );
}

export default App;
